package com.example.travelplannerapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.travelplannerapp.models.Hotel
import com.google.firebase.database.*
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import android.widget.ImageView

class MyPlannedTripsFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PlannedTripsAdapter
    private val plannedTrips = mutableListOf<PlannedTrip>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_my_planned_trips, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.browseRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = PlannedTripsAdapter(plannedTrips)
        recyclerView.adapter = adapter
        // Add a TextView for empty state feedback
        val emptyView = view.findViewById<TextView?>(R.id.emptyView)
        fetchPlannedTrips(emptyView)
    }

    private fun fetchPlannedTrips(emptyView: TextView? = null) {
        val database = FirebaseDatabase.getInstance()
        val tripsRef = database.getReference("trips")
        val currentUser = FirebaseAuth.getInstance().currentUser
        
        if (currentUser == null) {
            emptyView?.let {
                it.visibility = View.VISIBLE
                it.text = "Please login to view your planned trips."
            }
            return
        }
        
        // Add ValueEventListener to continuously listen for changes
        tripsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                plannedTrips.clear()
                for (tripSnapshot in snapshot.children) {
                    try {
                        val organizerId =
                            tripSnapshot.child("organizerId").getValue(String::class.java)

                        // Only add trips created by the current user
                        if (organizerId == currentUser.uid) {
                            val placeName =
                                tripSnapshot.child("placeName").getValue(String::class.java) ?: ""
                            val placeDescription =
                                tripSnapshot.child("placeDescription").getValue(String::class.java)
                                    ?: ""
                            val tripDescription =
                                tripSnapshot.child("tripDescription").getValue(String::class.java)
                                    ?: ""
                            val organizerName =
                                tripSnapshot.child("organizerName").getValue(String::class.java)
                                    ?: ""
                            val organizerPhone =
                                tripSnapshot.child("organizerPhone").getValue(String::class.java)
                                    ?: ""
                            val startDate =
                                tripSnapshot.child("startDate").getValue(String::class.java) ?: ""
                            val endDate =
                                tripSnapshot.child("endDate").getValue(String::class.java) ?: ""
                            val seatsAvailable =
                                tripSnapshot.child("seatsAvailable").getValue(String::class.java)
                                    ?: ""
                            val placeImageUrl =
                                tripSnapshot.child("placeImageUrl").getValue(String::class.java)

                            // Parse hotels
                            val hotelsList = mutableListOf<Hotel>()
                            val hotelsSnapshot = tripSnapshot.child("selectedHotels")
                            if (hotelsSnapshot.exists()) {
                                for (hotelSnapshot in hotelsSnapshot.children) {
                                    try {
                                        val hotel = hotelSnapshot.getValue(Hotel::class.java)
                                        if (hotel != null) {
                                            hotelsList.add(hotel)
                                        }
                                    } catch (e: Exception) {
                                        android.util.Log.e(
                                            "MyPlannedTripsFragment",
                                            "Error parsing hotel: ${e.message}"
                                        )
                                    }
                                }
                            }

                            // Create and add the planned trip
                            plannedTrips.add(
                                PlannedTrip(
                                    placeName,
                                    placeDescription,
                                    tripDescription,
                                    organizerName,
                                    organizerPhone,
                                    startDate,
                                    endDate,
                                    seatsAvailable,
                                    hotelsList,
                                    placeImageUrl
                                )
                            )
                        }
                    } catch (e: Exception) {
                        android.util.Log.e(
                            "MyPlannedTripsFragment",
                            "Error parsing trip: ${e.message}"
                        )
                    }
                }
                
                // Update UI
                adapter.notifyDataSetChanged()
                android.util.Log.d("MyPlannedTripsFragment", "Planned trips loaded: ${plannedTrips.size}")
                
                // Update empty view
                emptyView?.let {
                    if (plannedTrips.isEmpty()) {
                        it.visibility = View.VISIBLE
                        it.text = "No planned trips found."
                    } else {
                        it.visibility = View.GONE
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to load planned trips", Toast.LENGTH_SHORT).show()
                emptyView?.let {
                    it.visibility = View.VISIBLE
                    it.text = "Failed to load planned trips."
                }
            }
        })
    }
}

// Data class for displaying planned trips with hotels
data class PlannedTrip(
    val placeName: String,
    val placeDescription: String,
    val tripDescription: String,
    val organizerName: String,
    val organizerPhone: String,
    val startDate: String,
    val endDate: String,
    val seatsAvailable: String,
    val hotels: List<Hotel>,
    val placeImageUrl: String? = null
)

// Adapter for planned trips (simplified, you may want to move to its own file)
class PlannedTripsAdapter(private val trips: List<PlannedTrip>) : RecyclerView.Adapter<PlannedTripsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.trip_item, parent, false)
        return ViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trip = trips[position]
        holder.bind(trip)
    }
    
    override fun getItemCount(): Int = trips.size
    
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tripName: TextView = itemView.findViewById(R.id.tripTitleTextView)
        private val tripLocation: TextView = itemView.findViewById(R.id.tripLocationTextView)
        private val tripDescription: TextView = itemView.findViewById(R.id.tripDescriptionTextView)
        private val tripImageView: ImageView = itemView.findViewById(R.id.tripImageView)
        
        init {
            itemView.setOnClickListener {
                val trip = trips[adapterPosition]
                val intent = android.content.Intent(itemView.context, TripDetailActivity::class.java).apply {
                    putExtra("placeName", trip.placeName)
                    putExtra("placeDescription", trip.placeDescription)
                    putExtra("tripDescription", trip.tripDescription)
                    putExtra("organizerName", trip.organizerName)
                    putExtra("organizerPhone", trip.organizerPhone)
                    putExtra("startDate", trip.startDate)
                    putExtra("endDate", trip.endDate)
                    putExtra("seatsAvailable", trip.seatsAvailable)
                    putExtra("placeImageUrl", trip.placeImageUrl)
                    // Pass the hotels as a parcelable ArrayList
                    putParcelableArrayListExtra("hotels", ArrayList(trip.hotels))
                }
                itemView.context.startActivity(intent)
            }
        }
        
        fun bind(trip: PlannedTrip) {
            // Set trip name
            tripName.text = trip.placeName.takeIf { it.isNotBlank() } ?: "Unnamed Trip"
            
            // Set trip dates and seats
            tripLocation.text = buildString {
                append(trip.startDate)
                if (trip.endDate.isNotBlank()) {
                    append(" - ${trip.endDate}")
                }
                if (trip.seatsAvailable.isNotBlank()) {
                    append("  |  Seats: ${trip.seatsAvailable}")
                }
            }
            
            // Set trip description with all details
            val hotelNames = if (trip.hotels.isNotEmpty()) {
                trip.hotels.joinToString(", ") { it.name }
            } else "No hotels selected"
            
            val desc = buildString {
                if (trip.tripDescription.isNotBlank()) {
                    append(trip.tripDescription)
                    append("\n\n")
                }
                append("Hotels: $hotelNames")
                if (trip.placeDescription.isNotBlank()) {
                    append("\n\n")
                    append(trip.placeDescription)
                }
                append("\n\nOrganizer: ${trip.organizerName}")
                if (trip.organizerPhone.isNotBlank()) {
                    append(" (${trip.organizerPhone})")
                }
            }
            tripDescription.text = desc.trim()
            val imageUrl = when {
                !trip.placeImageUrl.isNullOrEmpty() -> trip.placeImageUrl
                trip.hotels.isNotEmpty() && !trip.hotels.first().imageUrl.isNullOrEmpty() -> trip.hotels.first().imageUrl
                else -> null
            }
            if (!imageUrl.isNullOrEmpty()) {
                try {
                    com.example.travelplannerapp.utils.ImageDatabaseLoader.loadImage(tripImageView, imageUrl)
                } catch (_: Exception) {
                    loadPlaceImageFromDrawable(trip.placeName, tripImageView)
                }
            } else {
                loadPlaceImageFromDrawable(trip.placeName, tripImageView)
            }
        }
    }
}

private fun loadPlaceImageFromDrawable(placeName: String, imageView: ImageView) {
    val context = imageView.context
    // Always use the placeholder image, as specific place images do not exist
    val resourceId = R.drawable.placeholder_image
    imageView.setImageResource(resourceId)
}
