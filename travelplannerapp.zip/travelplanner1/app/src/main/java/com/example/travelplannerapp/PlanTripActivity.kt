package com.example.travelplannerapp

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.travelplannerapp.adapters.HotelAdapter
import com.example.travelplannerapp.models.Hotel
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import java.util.Calendar

class PlanTripActivity : AppCompatActivity() {
    private lateinit var placeNameTextView: TextView
    private lateinit var placeDescriptionTextView: TextView
    private lateinit var placeImageView: ImageView
    private lateinit var hotelRecyclerView: RecyclerView
    private lateinit var tripDescriptionEditText: EditText
    private lateinit var organizerNameEditText: EditText
    private lateinit var organizerPhoneEditText: EditText
    private lateinit var startDateEditText: EditText
    private lateinit var endDateEditText: EditText
    private lateinit var seatsAvailableEditText: EditText
    private lateinit var createTripButton: Button

    private var selectedHotels: List<Hotel> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plan_trip)

        // Initialize Views
        placeNameTextView = findViewById(R.id.place_name)
        placeDescriptionTextView = findViewById(R.id.place_description)
        placeImageView = findViewById(R.id.place_image)
        hotelRecyclerView = findViewById(R.id.recycler_view_hotels)
        tripDescriptionEditText = findViewById(R.id.trip_description)
        organizerNameEditText = findViewById(R.id.organizer_name)
        organizerPhoneEditText = findViewById(R.id.organizer_phone)
        startDateEditText = findViewById(R.id.start_date)
        endDateEditText = findViewById(R.id.end_date)
        seatsAvailableEditText = findViewById(R.id.seats_available)
        createTripButton = findViewById(R.id.createTripButton)

        // Get the data passed from the previous activity (PlaceDetailActivity)
        val selectedPlaceName = intent.getStringExtra("PLACE_NAME") ?: "Unknown Place"
        val selectedPlaceDescription = intent.getStringExtra("PLACE_DESCRIPTION") ?: "No description available"
        val selectedPlaceImage = intent.getStringExtra("PLACE_IMAGE_URL") ?: ""

        // Set place info
        placeNameTextView.text = selectedPlaceName
        placeDescriptionTextView.text = selectedPlaceDescription

        // Load image from drawable
        if (selectedPlaceImage.isNotEmpty()) {
            com.example.travelplannerapp.utils.ImageDatabaseLoader.loadImage(placeImageView, selectedPlaceImage)
        } else {
            placeImageView.setImageResource(R.drawable.ic_placeholder)
        }

        // Load selected hotels from JSON
        val selectedHotelsJson = intent.getStringExtra("SELECTED_HOTELS")
        selectedHotelsJson?.let {
            val hotelListType = object : TypeToken<List<Hotel>>() {}.type
            selectedHotels = Gson().fromJson(it, hotelListType)
        }

        // Setup RecyclerView for hotels
        hotelRecyclerView.layoutManager = LinearLayoutManager(this)
        hotelRecyclerView.adapter = HotelAdapter(
            selectedHotels,
            onItemClick = { hotel ->
                // Handle hotel item click
            },
            onAddToCartClick = { hotel ->
                // Handle Add to Cart click
            }
        )

        // Set listeners for date pickers
        startDateEditText.setOnClickListener {
            showDatePickerDialog(startDateEditText)
        }
        endDateEditText.setOnClickListener {
            showDatePickerDialog(endDateEditText)
        }

        // Setup Create Trip button
        createTripButton.setOnClickListener {
            val tripDescription = tripDescriptionEditText.text.toString()
            val organizerName = organizerNameEditText.text.toString()
            val organizerPhone = organizerPhoneEditText.text.toString()
            val startDate = startDateEditText.text.toString()
            val endDate = endDateEditText.text.toString()
            val seatsAvailable = seatsAvailableEditText.text.toString()

            // Get current user UID for organizerId
            val organizerId = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: ""

            // Create trip data to save
            val tripData = hashMapOf(
                "placeName" to selectedPlaceName,
                "placeDescription" to selectedPlaceDescription,
                "tripDescription" to tripDescription,
                "organizerName" to organizerName,
                "organizerPhone" to organizerPhone,
                "startDate" to startDate,
                "endDate" to endDate,
                "seatsAvailable" to seatsAvailable,
                "selectedHotels" to selectedHotels,
                "organizerId" to organizerId,
                "placeImageUrl" to selectedPlaceImage
            )

            // Get reference to Firebase Realtime Database
            val database = FirebaseDatabase.getInstance()
            val tripsRef = database.getReference("trips")

            // Generate a unique key for this trip
            val tripKey = tripsRef.push().key

            if (tripKey != null) {
                // Save the trip data to the database
                tripsRef.child(tripKey).setValue(tripData)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Trip Created Successfully", Toast.LENGTH_SHORT).show()
                        finish() // Optionally return to previous screen
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Error creating trip: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Error: Could not generate trip ID", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to show the date picker dialog
    private fun showDatePickerDialog(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val date = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                editText.setText(date)
            },
            year, month, day
        )
        datePickerDialog.show()
    }
}