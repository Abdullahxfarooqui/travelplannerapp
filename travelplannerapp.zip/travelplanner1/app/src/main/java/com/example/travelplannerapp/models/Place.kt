package com.example.travelplannerapp.models

data class Place(
    val name: String,
    val description: String,
    val imageUrl: String
)