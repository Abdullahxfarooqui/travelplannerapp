package com.example.travelplannerapp.models


data class places(
    val name: String,
    val description: String,
    val imageUrl: String
)