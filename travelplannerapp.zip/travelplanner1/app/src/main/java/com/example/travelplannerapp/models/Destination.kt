package com.example.travelplannerapp.models

data class Destination(
    val hotels: List<Hotel>
)
